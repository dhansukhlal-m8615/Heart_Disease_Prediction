from django.db import models


# Create your models here.
class User_Admin(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(primary_key=True)
    password = models.CharField('password', max_length=100)


class Add_Tips(models.Model):
    title = models.CharField(max_length=50)
    description = models.TextField()


class Add_Doctors(models.Model):
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    contact_no = models.CharField(max_length=10)
    doctor_email = models.EmailField(primary_key=True)
    address = models.CharField(max_length=100)
    province = models.CharField(max_length=100)
    gender = models.CharField(max_length=6)
    user_postal = models.CharField(max_length=6)
    password = models.CharField('password', max_length=100)


class User_Patient(models.Model):
    firstName = models.CharField(max_length=100)
    lastName = models.CharField(max_length=100)
    patient_email = models.EmailField(primary_key=True)
    username = models.CharField(max_length=150)
    gender = models.CharField(max_length=6)
    address = models.CharField(max_length=150)
    province = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=6)
    phone = models.CharField(max_length=10)
    password = models.CharField('password', max_length=100)


class User_Records(models.Model):
    class Meta:
        unique_together = (('patient_email', 'date'),)

    patient_email = models.ForeignKey(User_Patient, on_delete=models.CASCADE)
    sex = models.CharField(max_length=1)
    age = models.CharField(max_length=10)
    restingBP = models.CharField(max_length=10)
    serum_cholestrol = models.CharField(max_length=10)
    max_heart_rate = models.CharField(max_length=10)
    Fluoroscopy_colored_major_vessels = models.CharField(max_length=10)
    chest_pain_type = models.CharField(max_length=10)
    fasting_BS_greaterthan_120 = models.BooleanField(max_length=10)
    peak_exercize = models.CharField(max_length=10)
    restingecg = models.CharField(max_length=10)
    exercise_induced_angima = models.BooleanField(max_length=10)
    ST_depression = models.CharField(max_length=100)
    thalium_stress = models.CharField(max_length=10)
    result = models.CharField(max_length=20)
    date = models.DateTimeField(auto_now=True, primary_key=True)


class Sent_Messages(models.Model):
    patient_email = models.ForeignKey(User_Patient, on_delete=models.CASCADE)
    doctor_email = models.ForeignKey(Add_Doctors, on_delete=models.CASCADE)
    sent_message = models.TextField()
    sent_by = models.CharField(max_length=10)
    date = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = (('patient_email', 'doctor_email', 'date'),)


class Feedback_Doctor(models.Model):
    doctor_email = models.ForeignKey(Add_Doctors, on_delete=models.CASCADE)
    comments = models.CharField(max_length=1000)
    date = models.DateTimeField(auto_now=True, primary_key=True)

    class Meta:
        unique_together = (('doctor_email', 'date'),)


class Feedback_Patient(models.Model):
    patient_email = models.ForeignKey(User_Patient, on_delete=models.CASCADE)
    comments = models.CharField(max_length=1000)
    date = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = (('patient_email', 'date'),)


class Training_Data(models.Model):
    age = models.CharField(max_length=10)
    sex = models.CharField(max_length=1)
    chest_pain_type = models.CharField(max_length=10)
    restingBP = models.CharField(max_length=10)
    serum_cholestrol = models.CharField(max_length=10)
    fasting_BS_greaterthan_120 = models.BooleanField(max_length=10)
    restingecg = models.CharField(max_length=10)
    max_heart_rate = models.CharField(max_length=10)
    exercise_induced_angima = models.BooleanField(max_length=10)
    ST_depression = models.CharField(max_length=100)
    peak_exercize = models.CharField(max_length=10)
    Fluoroscopy_colored_major_vessels = models.CharField(max_length=10)
    thalium_stress = models.CharField(max_length=10)
    target = models.CharField(max_length=20)

