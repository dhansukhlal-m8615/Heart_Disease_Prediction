import csv
import json

from django.contrib.sites import requests
from django.db import connection
from django.db.models import Q
from django.forms import forms
from django.shortcuts import render, redirect
import pandas as pd
from .analysis import AdaBoost_Classifier, ss
from .models import Add_Doctors, User_Patient, Training_Data, User_Records, Feedback_Patient, Feedback_Doctor, Add_Tips, \
    User_Admin, \
    Sent_Messages
from django.http import FileResponse, HttpResponse
import io
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter
import pyrebase
import win32api
import requests.exceptions
from django.db import connection

firebaseConfig = {
    "apiKey": "AIzaSyA-saCFmPsUdolkqVKo99btN2-1kmpOc0g",
    "authDomain": "heartdiseaseprediction-3fe1a.firebaseapp.com",
    "projectId": "heartdiseaseprediction-3fe1a",
    "databaseURL": "xxxxxx",
    "storageBucket": "heartdiseaseprediction-3fe1a.appspot.com",
    "messagingSenderId": "238231577148",
    "appId": "1:238231577148:web:d4dacca7602cb3d1e9d939",
    "measurementId": "G-E0210YFMK3"
}
firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()


# email = input("Please Enter Your Email Address : \n")
# password = getpass("Please Enter Your Password : \n")

# create users

# print("Success .... ")


# send email verification
# auth.send_email_verification(login['idToken'])

# reset the password
# auth.send_password_reset_email(email)

# print("Success ... ")

def home(request):
    return render(request, "home.html")


def login_admin(request):
    return render(request, "login_admin.html")


def login_admin_confirmed(request):
    p_email = request.POST.get('email')
    password = request.POST.get('pass')
    valid_admin = User_Admin.objects.filter(email=p_email)
    if valid_admin:
        try:
            login = auth.sign_in_with_email_and_password(p_email, password)
            return render(request, "add_doctor.html")
        except requests.exceptions.HTTPError as httpErr:
            error_message = json.loads(httpErr.args[1])['error']['message']
            win32api.MessageBox(0, error_message)
            return render(request, "login_admin.html")
    else:
        win32api.MessageBox(0, "Email doesn't exist")
        return render(request, "login_admin.html")


def view_doctors(request):
    doctors = Add_Doctors.objects.all()
    return render(request, "view_doctors.html", {"doctors": doctors})


def find_cardiologist(request):
    doctors = Add_Doctors.objects.all()
    return render(request, "find_cardiologist.html", {"doctors": doctors})


def heart_tips(request):
    heart_tip = Add_Tips.objects.all()
    args = {"heart_tip": heart_tip}
    return render(request, "heart_tips.html", args)


def view_feedback(request):
    cursor = connection.cursor()
    cursor1 = connection.cursor()
    cursor.execute(
        "SELECT firstName, lastName, patient_email, phone, comments, date FROM project_db.heartdiseaseprediction_feedback_patient JOIN project_db.heartdiseaseprediction_user_patient ON project_db.heartdiseaseprediction_feedback_patient.patient_email_id=project_db.heartdiseaseprediction_user_patient.patient_email")
    cursor1.execute(
        "SELECT fname, lname, doctor_email, contact_no, comments, date FROM project_db.heartdiseaseprediction_feedback_doctor JOIN project_db.heartdiseaseprediction_add_doctors ON project_db.heartdiseaseprediction_feedback_doctor.doctor_email_id=project_db.heartdiseaseprediction_add_doctors.doctor_email")
    feedback_doc = cursor1.fetchall()
    feedback_pat = cursor.fetchall()
    args = {"feedback_doc": feedback_doc, "feedback_pat": feedback_pat}
    return render(request, "view_feedback.html", args)


def login_doctor(request):
    return render(request, "login_doctor.html")


def login_doctor_confirmed(request):
    p_email = request.POST.get('email')
    password = request.POST.get('pass')
    valid_doctor = Add_Doctors.objects.filter(doctor_email=p_email)
    if valid_doctor:
        try:
            login = auth.sign_in_with_email_and_password(p_email, password)
            return render(request, "feedback_doctor.html")
        except requests.exceptions.HTTPError as httpErr:
            error_message = json.loads(httpErr.args[1])['error']['message']
            win32api.MessageBox(0, error_message)
            return render(request, "login_doctor.html")
    else:
        win32api.MessageBox(0, "Email doesn't exist")
        return render(request, "login_doctor.html")


def login_patient(request):
    return render(request, "login_patient.html")


def add_doctor(request):
    return render(request, "add_doctor.html")


def login_patient_confirmed(request):
    p_email = request.POST.get('email')
    password = request.POST.get('pass')
    valid_patient = User_Patient.objects.filter(patient_email=p_email)
    if valid_patient:
        try:
            login = auth.sign_in_with_email_and_password(p_email, password)
            return render(request, "heart_analysis_form.html")
        except requests.exceptions.HTTPError as httpErr:
            error_message = json.loads(httpErr.args[1])['error']['message']
            win32api.MessageBox(0, error_message)
            return render(request, "login_patient.html")
    else:
        win32api.MessageBox(0, "Email doesn't exist")
        return render(request, "login_patient.html")


def patient_profile(request):
    email = auth.current_user['email']
    print(email)
    user = User_Patient.objects.filter(patient_email=email)
    return render(request, 'patient_profile.html', {'user': user})


def add_doctor_confirmed(request):
    first_name = request.POST["first_name"]
    last_name = request.POST["last_name"]
    user_name = request.POST["user_name"]
    email = request.POST.get("email")
    password = request.POST.get("user_password")
    contact_no = request.POST["contact_no"]
    radiogroup1 = request.POST["radiogroup1"]
    user_address = request.POST["user_address"]
    province = request.POST["province"]
    user_postal = request.POST["user_postal"]
    try:
        user = auth.create_user_with_email_and_password(email, password)
        Add_Doctor = Add_Doctors(fname=first_name, lname=last_name, username=user_name, password=password,
                                 doctor_email=email, contact_no=contact_no, gender=radiogroup1,
                                 address=user_address,
                                 province=province,
                                 user_postal=user_postal)

        Add_Doctor.save()
        return render(request, "add_doctor.html")
    except requests.exceptions.HTTPError as httpErr:
        error_message = json.loads(httpErr.args[1])['error']['message']
        win32api.MessageBox(0, error_message)
        return render(request, "add_doctor.html")


def registration_form_confirmed(request):
    first_name = request.POST["first_name"]
    last_name = request.POST["last_name"]
    user_name = request.POST["user_name"]
    p_email = request.POST.get("patient_email")
    password = request.POST.get("password")
    contact_no = request.POST["contact_no"]
    gender = request.POST["gender"]
    address = request.POST["address"]
    province = request.POST["province"]
    postal_code = request.POST["postal_code"]
    try:
        user = auth.create_user_with_email_and_password(p_email, password)
        User_Patients = User_Patient(firstName=first_name, lastName=last_name, username=user_name, password=password,
                                     patient_email=p_email, phone=contact_no, gender=gender, address=address,
                                     province=province,
                                     postal_code=postal_code)
        User_Patients.save()
        return render(request, "login_patient.html")
    except requests.exceptions.HTTPError as httpErr:
        error_message = json.loads(httpErr.args[1])['error']['message']
        win32api.MessageBox(0, error_message)
        return render(request, "registration_form.html")


def heart_analysis_form(request):
    return render(request, "heart_analysis_form.html")


def patient_message_sent(request):
    return render(request, "patient_message_sent.html")


def view_patients(request):
    doctor_email = auth.current_user['email']
    cursor2 = connection.cursor()
    cursor2.execute(
        "SELECT distinct firstName, lastName, doctor_email_id, patient_email_id FROM project_db.heartdiseaseprediction_sent_messages JOIN project_db.heartdiseaseprediction_user_patient ON patient_email_id=patient_email WHERE doctor_email_id='" + doctor_email + "' ORDER BY date desc")
    patients_list = cursor2.fetchall()
    args = {"patients_list": patients_list}
    return render(request, "view_patients.html", args)


def patient_heart_records(request, p_email):
    heart_records = User_Records.objects.filter(patient_email_id=p_email)
    args = {"heart_records": heart_records}
    return render(request, "patient_heart_records.html", args)


def patient_chatroom(request):
    patient_email = auth.current_user['email']
    cursor2 = connection.cursor()
    cursor2.execute(
        "SELECT distinct fname, lname, doctor_email_id, patient_email_id FROM project_db.heartdiseaseprediction_sent_messages JOIN project_db.heartdiseaseprediction_add_doctors ON doctor_email_id=doctor_email WHERE patient_email_id='" + patient_email + "' ORDER BY date desc")
    doctors_list = cursor2.fetchall()
    args = {"doctors_list": doctors_list}
    return render(request, "patient_chatroom.html", args)


def pick_doctor_email(request, doctor_email, patient_email):
    args = {"doctor_email": doctor_email, "patient_email": patient_email}
    return render(request, "message_platform.html", args)


def view_messages_patients(request):
    patient_email = auth.current_user['email']
    doctor_email = request.POST['doctor_email']
    print("email" + doctor_email)
    cursor2 = connection.cursor()
    cursor2.execute(
        "SELECT distinct fname, lname, firstName, lastName, doctor_email_id, patient_email_id, sent_message, date, sent_by FROM project_db.heartdiseaseprediction_sent_messages JOIN project_db.heartdiseaseprediction_add_doctors ON doctor_email_id=doctor_email JOIN project_db.heartdiseaseprediction_user_patient ON patient_email_id=patient_email WHERE doctor_email_id='" + doctor_email + "' AND patient_email_id='" + patient_email + "' ORDER BY date asc ")
    message_list = cursor2.fetchall()
    args = {"message_list": message_list}
    return render(request, "view_messages_patients.html", args)


def message_platform(request):
    patient_email = auth.current_user['email']
    p_email = User_Patient.objects.get(patient_email=patient_email)
    message_sent_patient = request.POST["msg_patient"]
    d_email = request.POST["d_email"]
    doctor_email = Add_Doctors.objects.get(doctor_email=d_email)
    sent_by = "patient"

    sent_message = Sent_Messages(patient_email=p_email, doctor_email=doctor_email, sent_message=message_sent_patient,
                                 sent_by=sent_by)
    sent_message.save()
    return render(request, "message_platform.html")


def message_platform_chatroom(request, doctor_email):
    temp = 0
    patient_email = auth.current_user['email']
    p_email = User_Patient.objects.get(patient_email=patient_email)
    cursor = connection.cursor()
    cursor.execute(
        "SELECT * FROM project_db.heartdiseaseprediction_sent_messages WHERE doctor_email_id='" + doctor_email + "' AND patient_email_id='" + patient_email + "'")
    messages = cursor.fetchall()
    print(len(messages))
    if len(messages) == 0:
        return render(request, "message_platform.html", {"doctor_email": doctor_email})
    else:
        cursor2 = connection.cursor()
        cursor2.execute(
            "SELECT distinct fname, lname, doctor_email_id, patient_email_id FROM project_db.heartdiseaseprediction_sent_messages JOIN project_db.heartdiseaseprediction_add_doctors ON doctor_email_id=doctor_email WHERE doctor_email_id='" + doctor_email + "' AND patient_email_id='" + patient_email + "'")
        doctors_list = cursor2.fetchall()
        args = {"doctors_list": doctors_list}
        temp = temp + 1
        return render(request, "patient_chatroom.html", args)


def doctor_chatroom(request):
    doctor_email = auth.current_user['email']
    cursor2 = connection.cursor()
    cursor2.execute(
        "SELECT distinct firstName, lastName, doctor_email_id, patient_email_id FROM project_db.heartdiseaseprediction_sent_messages JOIN project_db.heartdiseaseprediction_add_doctors ON doctor_email_id=doctor_email JOIN project_db.heartdiseaseprediction_user_patient ON patient_email_id=patient_email WHERE doctor_email_id='" + doctor_email + "' ORDER BY date desc")
    message_list = cursor2.fetchall()
    args = {"message_list": message_list}
    return render(request, "doctor_chatroom.html", args)


def view_message_doctor(request, patient_email):
    doctor_email = auth.current_user['email']
    cursor2 = connection.cursor()
    cursor2.execute(
        "SELECT distinct firstName, lastName, doctor_email_id, patient_email_id, sent_message, sent_by, date, fname, lname FROM project_db.heartdiseaseprediction_sent_messages JOIN project_db.heartdiseaseprediction_add_doctors ON doctor_email_id=doctor_email JOIN project_db.heartdiseaseprediction_user_patient ON patient_email_id=patient_email WHERE patient_email_id='" + patient_email + "' AND doctor_email_id='" + doctor_email + "' ORDER BY date asc")
    message_list = cursor2.fetchall()
    return render(request, "view_message_doctor.html", {"message_list": message_list})


def pick_patient_email(request, doctor_email, patient_email):
    args = {"doctor_email": doctor_email, "patient_email": patient_email}
    return render(request, "message_platform_doctor.html", args)


def message_platform_doctor(request):
    message_sent_patient = request.POST["msg_patient"]
    d_email = request.POST["d_email"]
    patient_email = request.POST["p_email"]
    p_email = User_Patient.objects.get(patient_email=patient_email)
    doctor_email = Add_Doctors.objects.get(doctor_email=d_email)
    sent_by = "doctor"

    sent_message = Sent_Messages(patient_email=p_email, doctor_email=doctor_email, sent_message=message_sent_patient,
                                 sent_by=sent_by)
    sent_message.save()
    return render(request, "message_platform_doctor.html")


def add_tips(request):
    return render(request, "add_tips.html")


def add_tips_confirmed(request):
    title = request.POST["title"]
    description = request.POST["description"]

    add_tip = Add_Tips(title=title, description=description)
    add_tip.save()
    return render(request, "add_tips.html")


def add_training_data(request):
    return render(request, "add_training_data.html")


def registration_form(request):
    return render(request, "registration_form.html")


def feedback_patient_confirmed(request):
    u = auth.current_user['email']
    comments = request.POST["comments"]

    patient_feedback = Feedback_Patient(comments=comments, patient_email_id=u)
    patient_feedback.save()
    return render(request, "feedback_patient.html")


def feedback_patient(request):
    return render(request, "feedback_patient.html")


def feedback_doctor_confirmed(request):
    comments = request.POST["comments"]
    u = auth.current_user['email']
    doctor_feedback = Feedback_Doctor(comments=comments, doctor_email_id=u)
    doctor_feedback.save()
    return render(request, "feedback_doctor.html")


def download_heart_record(request):
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=letter, bottomup=0)
    textob = c.beginText()
    textob.setTextOrigin(inch, inch)
    date = request.POST['date']
    lines = []
    cur_user = auth.current_user['email']
    records = User_Records.objects.filter(date=date, patient_email_id=cur_user)
    user_det = User_Patient.objects.filter(patient_email=cur_user)

    for record in records:
        lines.append(
            "                                               HEART ANALYSIS PREDICTION                                               ")
        lines.append(" ")
        for user in user_det:
            lines.append(user.firstName + " " + user.lastName)
            lines.append(user.patient_email)
            lines.append(user.address + "," + user.province + "," + user.postal_code)
            lines.append(" ")
            lines.append("Gender: " + user.gender)

        lines.append(" ")
        lines.append("Date: " + format(record.date))
        lines.append(" ")
        lines.append("Sex: " + format(record.sex) + "                                               Age: " + format(
            record.age) + "                                                   Result: " + format(record.result))
        lines.append(" ")
        lines.append("Resting Blood Pressure:                        " + format(record.restingBP))
        lines.append(" ")
        lines.append("Serum Cholesterol:                                " + format(record.serum_cholestrol))
        lines.append(" ")
        lines.append("Maximum Heart Rate:                            " + format(record.max_heart_rate))
        lines.append(" ")
        lines.append("Number of Major Vessels")
        lines.append(
            "colored by Fluoroscopy:                        " + format(record.Fluoroscopy_colored_major_vessels))
        lines.append(" ")
        lines.append("Chest Pain Type:                                   " + format(record.chest_pain_type))
        lines.append(" ")
        lines.append("Fasting Blood Sugar:                           " + format(record.fasting_BS_greaterthan_120))
        lines.append(" ")
        lines.append("Peak Exercise ST Segment:                   " + format(record.peak_exercize))
        lines.append(" ")
        lines.append("Resting ECG Results:                              " + format(record.restingecg))
        lines.append(" ")
        lines.append("Exercise Induced Angina:                       " + format(record.exercise_induced_angima))
        lines.append(" ")
        lines.append("ST Depression induced by")
        lines.append("exercise relative to rest:                        " + format(record.ST_depression))
        lines.append(" ")
        lines.append("Thallium Stress:                                     " + format(record.thalium_stress))

    for line in lines:
        textob.textLine(line)

    c.drawText(textob)
    c.showPage()
    c.save()
    buf.seek(0)
    return FileResponse(buf, as_attachment=True, filename="heart_record.pdf")


def feedback_doctor(request):
    return render(request, "feedback_doctor.html")


def doctor_profile(request):
    email = auth.current_user['email']
    print(email)
    user = Add_Doctors.objects.filter(doctor_email=email)
    return render(request, 'doctor_profile.html', {'user': user})


def view_heart_records(request):
    user_email = auth.current_user['email']
    heart_records = User_Records.objects.filter(patient_email_id=user_email)
    args = {"heart_records": heart_records}
    return render(request, "view_heart_records.html", args)


def result(request):
    age = int(request.POST["age"])
    restingBP = int(request.POST["restbp"])
    fastingBS = int(request.POST["fastingbp"])
    val1 = int(request.POST['sex'])
    val2 = int(request.POST['chol'])
    val3 = int(request.POST['maxhr'])
    val4 = int(request.POST['fluor'])
    val5 = int(request.POST['chestPain'])
    val6 = int(request.POST['peakEx'])
    val7 = int(request.POST['restingECG'])
    val8 = int(request.POST['exang'])
    val9 = float(request.POST['stDep'])
    val10 = int(request.POST['thal'])

    df1 = pd.DataFrame([[val1, val5, val2, val7, val3, val8, val9, val6, val4, val10]])
    prediction = AdaBoost_Classifier.predict(df1)
    if prediction == [1]:
        result2 = "Present"
    elif prediction == [0]:
        result2 = "Absent"
    else:
        result2 = "ERROR"
    patient_e = auth.current_user['email']
    User_Record = User_Records(sex=val1, age=age, restingBP=restingBP,
                               serum_cholestrol=val2, max_heart_rate=val3,
                               Fluoroscopy_colored_major_vessels=val4, chest_pain_type=val5,
                               fasting_BS_greaterthan_120=fastingBS, peak_exercize=val6,
                               restingecg=val7, exercise_induced_angima=val8,
                               ST_depression=val9, thalium_stress=val10, result=result2,
                               patient_email_id=patient_e)

    User_Record.save()
    return render(request, "heart_analysis_form.html", {"result2": result2})


def view_training_data(request):
    process_data()
    training_Data = Training_Data.objects.all()
    args = {"training_Data": training_Data}
    return render(request, "view_training_data.html", args)


def process_data():
    Training_Data.objects.all().delete()
    with open(
            r'C:\Users\User\Desktop\Applied Research Project\HeartDiseasePrediction (8) (1)\HeartDiseasePrediction\HeartDiseasePrediction\HeartDiseasePrediction\heart.csv') as csv_file:  # Opens the file in read mode
        csv_reader = csv.reader(csv_file)  # Making use of reader method for reading the file

        for i, line in enumerate(csv_reader):  # Iterate through the loop to read line by line
            if i == 0:
                pass
            else:  #
                line = " ".join(line)
                age, sex, chest_pain_type, restingBP, serum_cholestrol, fasting_BS_greaterthan_120, restingecg, max_heart_rate, exercise_induced_angima, ST_depression, peak_exercize, Fluoroscopy_colored_major_vessels, thalium_stress, target = line.split()
                training = Training_Data(sex=sex, age=age, restingBP=restingBP,
                                         serum_cholestrol=serum_cholestrol, max_heart_rate=max_heart_rate,
                                         Fluoroscopy_colored_major_vessels=Fluoroscopy_colored_major_vessels,
                                         chest_pain_type=chest_pain_type,
                                         fasting_BS_greaterthan_120=fasting_BS_greaterthan_120,
                                         peak_exercize=peak_exercize,
                                         restingecg=restingecg, exercise_induced_angima=exercise_induced_angima,
                                         ST_depression=ST_depression, thalium_stress=thalium_stress, target=target,
                                         )
                training.save()
