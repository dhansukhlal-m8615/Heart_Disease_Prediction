"""HeartDiseasePrediction URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from .views import (
    home, login_patient, feedback_patient, add_doctor
)
from . import views
from django.views.generic import TemplateView

urlpatterns = [
    url('r^admin/', admin.site.urls),
    url(r'^$', views.home, name='home'),
    url(r'^heart_tips', views.heart_tips, name='heart_tips'),
    url(r'^login_admin/$', views.login_admin, name='login_admin'),
    url(r'^login_admin_confirmed/$', views.login_admin_confirmed, name='login_admin_confirmed'),
    url(r'^login_patient/$', views.login_patient, name='login_patient'),
    url(r'^login_patient_confirmed/$', views.login_patient_confirmed, name='login_patient_confirmed'),
    url(r'^login_doctor/$', views.login_doctor, name='login_doctor'),
    url(r'^login_doctor_confirmed/$', views.login_doctor_confirmed, name='login_doctor_confirmed'),
    url(r'^login_doctor/find_cardiologist', views.find_cardiologist, name='find_cardiologist'),
    url(r'^login_admin/add_doctor/$', views.add_doctor, name='add_doctor'),
    url(r'^login_admin/view_doctors/$', views.view_doctors, name='view_doctors'),
    url(r'^login_admin/view_feedback/$', views.view_feedback, name='view_feedback'),
    url(r'^login_admin/view_training_data/$', views.view_training_data, name='view_training_data'),
    url(r'^login_admin/add_doctor_confirmed/$', views.add_doctor_confirmed, name='add_doctor_confirmed'),
    url(r'^login_admin/add_tips/$', views.add_tips, name='add_tips'),
    url(r'^login_admin/add_tips_confirmed/$', views.add_tips_confirmed, name='add_tips_confirmed'),
    url(r'^login_admin/add_training_data/$', views.add_training_data, name='add_training_data'),
    url(r'^registration_form/$', views.registration_form, name='registration_form'),
    url(r'^registration_form_confirmed/$', views.registration_form_confirmed, name='registration_form_confirmed'),
    url(r'^login_doctor/feedback_doctor/$', views.feedback_doctor, name='feedback_doctor'),
    url(r'^login_doctor/view_patients/$', views.view_patients, name='view_patients'),
    url(r'^login_doctor/view_patients/patient_heart_records/(?P<p_email>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})$', views.patient_heart_records, name='patient_heart_records'),
    url(r'^login_doctor/feedback_doctor_confirmed/$', views.feedback_doctor_confirmed,
        name='feedback_doctor_confirmed'),
    url(r'^login_doctor/doctor_profile/$', views.doctor_profile, name='doctor_profile'),
    url(r'^login_patient/message_sent/$', views.patient_message_sent, name='patient_message_sent'),
    url(r'^login_patient/patient_chatroom/view_messages_patients/pick_doctor_email/(?P<doctor_email>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})/(?P<patient_email>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})/$',
        views.pick_doctor_email,
        name='pick_doctor_email'),
    url(r'^login_doctor/doctor_chatroom/$', views.doctor_chatroom, name='doctor_chatroom'),
    url(r'^login_doctor/doctor_chatroom/view_message_doctor/(?P<patient_email>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})/$',
        views.view_message_doctor, name='view_message'),
    url(r'^login_doctor/doctor_chatroom/view_message_doctor/message_platform_doctor/$',
        views.message_platform_doctor, name='message_platform_doctor'),
    url(r'^login_doctor/doctor_chatroom/view_message_doctor/pick_patient_email/(?P<doctor_email>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})/(?P<patient_email>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})$',
        views.pick_patient_email, name='pick_patient_email'),
    url(r'^login_patient/feedback_patient/$', views.feedback_patient, name='feedback_patient'),
    url(r'^login_patient/feedback_patient_confirmed/$', views.feedback_patient_confirmed,
        name='feedback_patient_confirmed'),
    url(r'^login_patient/patient_chatroom/$', views.patient_chatroom, name='patient_chatroom'),
    url(r'^login_patient/patient_chatroom/view_messages_patients/$', views.view_messages_patients,
        name='view_messages_patients'),
    url(r'^login_patient/find_cardiologist/message_platform_chatroom/(?P<doctor_email>[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4})/$',
        views.message_platform_chatroom, name='message_platform_chatroom'),
    url(r'^login_patient/find_cardiologist/message_platform/$',
        views.message_platform, name='message_platform'),

    url(r'^login_patient/download_heart_record/$', views.download_heart_record,
        name='download_heart_record'),
    url(r'^login_patient/view_heart_records/$', views.view_heart_records,
        name='view_heart_records'),
    url(r'^patient_profile/$', views.patient_profile, name='patient_profile'),
    url(r'login_patient/heart_analysis_form/$', views.heart_analysis_form, name='heart_analysis_form'),
    url(r'^login_patient/heart_analysis_form/result/$', views.result, name='result'),
]
