from django.apps import AppConfig


class HeartDisease(AppConfig):
    name = 'HeartDiseasePrediction'
